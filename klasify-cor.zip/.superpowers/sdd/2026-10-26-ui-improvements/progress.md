# SDD ledger — plan: docs/superpowers/plans/2026-10-26-ui-improvements.md
Pre-flight: no shared interfaces
