import 'sectioned_schedule_parser.dart';

/// Reads a Certificate of Registration (COR): one enrolled subject per row,
/// with its printed schedule in a "hh:mm AM - hh:mm PM / Day" cell, followed
/// by room and faculty cells.
///
/// Expected row shape, after OCR (columns may be separated by spaces):
///
///   IT 104 Data Structures and Algorithm 3 BSIT-2A 08:00 AM - 09:30 AM / Mon Rm 301 Prof. Ana Reyes
///
/// Rules:
///  * the code is the first token group (IT 104, IT 104L, GE C03, PE 03,
///    IT Elec2, IT FE1); the description runs until the units digit;
///  * a row with a time cell but no code is a continuation of the subject
///    above it (a second meeting of the same subject). It is emitted with the
///    carried subject and flagged for review;
///  * rows without a time cell are enrolled subjects with no printed
///    schedule (a blank-schedule COR). They emit no class, because a class
///    needs a day and a time;
///  * "tba" and "Online" cells are ignored, and the Faculty and Room cells
///    are split at the first faculty title (Prof., Coach, Dr., Engr.).
class CorScheduleParser {
  CorScheduleParser._();

  static const double _continuationConfidence = 0.74;

  static final RegExp _slot = RegExp(
    r'(\d{1,2})[:.](\d{2})\s*(AM|PM)\s*[-–—]\s*(\d{1,2})[:.](\d{2})\s*(AM|PM)\s*/\s*([A-Za-z]{3,9})',
    caseSensitive: false,
  );

  static final RegExp _formTitle = RegExp(
    r'certificate\s+of\s+registration',
    caseSensitive: false,
  );

  static final RegExp _columnHeaders = RegExp(
    r'\bunits?\b[\s\S]*\bfaculty\b|\bfaculty\b[\s\S]*\bunits?\b',
    caseSensitive: false,
  );

  static final RegExp _facultyStart = RegExp(
    r'\b(Prof\.?|Professor|Coach|Dr\.?|Engr\.?|Mr\.?|Ms\.?|Mrs\.?|Sir)\s',
    caseSensitive: false,
  );

  static final RegExp _codeAndDescription = RegExp(
    r'^((?:[A-Za-z]{1,4}\s)?[A-Za-z]{1,4}\s?\d{1,3}[A-Za-z]{0,2}\d?)\s+(\S.*)$',
  );

  static final RegExp _trailingUnits = RegExp(r'\s(\d)\s*$');
  static final RegExp _trailingSection = RegExp(
    r'\s+(?:BS[A-Za-z]*-?\s?\d[A-Za-z]?|[A-Za-z]{2,5}-\d[A-Za-z]?)\s*$',
    caseSensitive: false,
  );
  static final RegExp _roomCell = RegExp(
    r'\b(?:(?:Rm|Room)\.?\s*[\w-]+|Lab\s+\d+|MacLab|Gym|Laboratory|Lab)\b',
    caseSensitive: false,
  );
  static final RegExp _tbaCell = RegExp(
    r'\b(tba|online)\b',
    caseSensitive: false,
  );

  /// Whether [text] looks like a COR: the printed form title appears, or a
  /// schedule cell appears together with the Units and Faculty column
  /// headers. Ordinary timetables with a "Time / Day" or "Room" header do not
  /// match, so they keep their existing parser.
  static bool looksLikeCor(String text) {
    if (_formTitle.hasMatch(text)) return true;
    return _slot.hasMatch(text) && _columnHeaders.hasMatch(text);
  }

  /// Parses COR rows from OCR or extracted text, one row per line.
  static List<SectionedRow> parse(String raw) {
    final lines = raw
        .replaceAll('\r', '\n')
        .split('\n')
        .map((line) => line.replaceAll(RegExp(r'\s+'), ' ').trim())
        .where((line) => line.isNotEmpty);

    final rows = <SectionedRow>[];
    String? carriedSubject;
    String? carriedCode;

    for (final line in lines) {
      final slot = _slot.firstMatch(line);
      if (slot == null) continue;

      final day = _dayNumber(slot.group(7)!);
      if (day == null) continue;
      final start = _minutes(slot.group(1)!, slot.group(2)!, slot.group(3)!);
      final end = _minutes(slot.group(4)!, slot.group(5)!, slot.group(6)!);
      if (end <= start) continue;

      final before = line.substring(0, slot.start).trim();
      final after = line.substring(slot.end).trim();

      final parsedHead = _parseHead(before);
      final String subject;
      final List<String> assumptions;
      final double? confidence;
      if (parsedHead != null) {
        subject = parsedHead.description;
        carriedSubject = subject;
        carriedCode = parsedHead.code;
        assumptions = const [];
        confidence = null;
      } else if (carriedSubject != null) {
        subject = carriedSubject;
        assumptions = [
          'Second meeting of $carriedCode, read from the row above.',
        ];
        confidence = _continuationConfidence;
      } else {
        continue;
      }

      final cells = _splitRoomAndFaculty(after);
      rows.add(
        SectionedRow(
          subject: subject,
          day: day,
          startMinutes: start,
          endMinutes: end,
          room: cells.room,
          professor: cells.professor,
          ocrConfidence: confidence,
          assumptions: assumptions,
        ),
      );
    }
    return rows;
  }

  /// Splits the text before the schedule cell into code, description and
  /// units. Returns null when no code is present (a continuation line).
  static ({String code, String description})? _parseHead(String before) {
    var head = before.replaceFirst(_trailingSection, '').trim();
    head = head.replaceFirst(_trailingUnits, '').trim();
    final match = _codeAndDescription.firstMatch(head);
    if (match == null) return null;
    final code = match.group(1)!.trim();
    final description = match.group(2)!.trim();
    if (description.isEmpty) return null;
    return (code: code, description: description);
  }

  /// The room and faculty cells can come in either order, so the room token
  /// is found first and the rest of the text is the faculty name.
  static ({String room, String professor}) _splitRoomAndFaculty(String after) {
    final cleaned = after
        .replaceAll(_tbaCell, '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    final roomMatch = _roomCell.firstMatch(cleaned);
    final room = roomMatch?.group(0)?.trim() ?? '';
    final rest = roomMatch == null
        ? cleaned
        : cleaned.replaceRange(roomMatch.start, roomMatch.end, '').trim();
    final faculty = _facultyStart.firstMatch(rest);
    final professor = faculty == null ? rest : rest.substring(faculty.start);
    return (room: room, professor: professor.trim());
  }

  static int _minutes(String hour, String minute, String meridiem) {
    var h = int.parse(hour) % 12;
    if (meridiem.toUpperCase() == 'PM') h += 12;
    return h * 60 + int.parse(minute);
  }

  /// Weekday 1..7 (Monday = 1), matching the app's day convention.
  static int? _dayNumber(String word) {
    switch (word.toLowerCase().substring(0, 3)) {
      case 'mon':
        return 1;
      case 'tue':
        return 2;
      case 'wed':
        return 3;
      case 'thu':
        return 4;
      case 'fri':
        return 5;
      case 'sat':
        return 6;
      case 'sun':
        return 7;
    }
    return null;
  }
}
